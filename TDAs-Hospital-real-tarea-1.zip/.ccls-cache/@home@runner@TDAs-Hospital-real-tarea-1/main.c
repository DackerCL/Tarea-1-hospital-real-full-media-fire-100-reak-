#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


// Función para limpiar la pantalla
void limpiarPantalla() { system("clear"); }

void presioneTeclaParaContinuar() {
  puts("Presione una tecla para continuar...");
  getchar(); // Consume el '\n' del buffer de entrada
  getchar(); // Espera a que el usuario presione una tecla
}

// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}
// Función para ordenar la lista de pacientes por prioridad y fecha de ingreso

void ordenar_pacientes(List *pacientes){
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  int intercambios = 0;

  do {
    intercambios = 0;
    Node *current = pacientes->head;
    while (current->next != NULL){
      paciente *paciente_actual = (paciente *)current->data;
      paciente *paciente_siguiente = (paciente *)current->next->data;
      if(paciente_actual->prioridad > paciente_siguiente->prioridad || (paciente_actual->prioridad == paciente_siguiente->prioridad 
        && paciente_actual->fecha_ingreso > paciente_siguiente->fecha_ingreso)) {
        void *temp = current->data;
        current->data = current->next->data;
        current->next->data= temp;
        intercambios++;
      }
        current= current->next;
    }
  } while (intercambios);
}
// Función para registrar un nuevo paciente

void registrar_paciente(List *pacientes) {
  printf("Registrar nuevo paciente\n");
  char nombre[60];
  int edad;
  char enfermedad[100];

  printf("Ingrese el nombre del paciente: ");
  scanf(" %[^\n]", nombre);
  printf("Ingrese la edad del paciente: ");
  scanf("%d", &edad);
  printf("Ingrese la enfermedad del paciente: ");
  scanf(" %[^\n]", enfermedad);

  paciente *nuevo_paciente = (paciente *)malloc(sizeof(paciente));
  if(nuevo_paciente == NULL){
    printf("Error al asignar memoria para el paciente\n");
    free(nuevo_paciente);
    return;
  }
  strcpy(nuevo_paciente->nombre, nombre);
  nuevo_paciente->edad = edad;
  strcpy(nuevo_paciente->enfermedad, enfermedad);
  time_t tiempo_actual = time(NULL);
  nuevo_paciente->fecha_ingreso = tiempo_actual;
  nuevo_paciente->prioridad = bajo;
  list_pushBack(pacientes, nuevo_paciente);
}
// Función para asignar prioridad a un paciente existente

void asignar_prioridad (List *pacientes) {
  printf("Asignar prioridad a paciente\n");
  char nombre[60];
  printf("Ingrese el nombre del paciente: ");
  scanf(" %[^\n]", nombre);
  Node *current = pacientes->head;
  while (current != NULL) {
    paciente *paciente_actual = (paciente *)current->data;
    if (strcmp(paciente_actual->nombre, nombre) == 0) { //Si son iguales
      printf("Ingrese la prioridad del paciente:\n\n 1) alto\n 2) medio\n 3) bajo\n\n");
      int prioridad;
      scanf("%d", &prioridad);
      switch (prioridad) {
        case 1:
          paciente_actual->prioridad = alto;
          printf("La prioridad del paciente %s ha sido actualizada a Alto.\n", paciente_actual->nombre);
          break;
        case 2:
          paciente_actual->prioridad = medio;
          printf("La prioridad del paciente %s ha sido actualizada a Medio.\n", paciente_actual->nombre);
          break;
        case 3:
          paciente_actual->prioridad = bajo;
          printf("La prioridad del paciente %s ha sido actualizada a Bajo.\n", paciente_actual->nombre);
          break;
        default:
          printf("Prioridad inválida\n");
          return;
      }
      printf("Prioridad asignada con éxito\n");
    }
    current = current->next;
  }
}
// Función para mostrar la lista de pacientes en espera

void mostrar_lista_pacientes(List *pacientes) {
  // Mostrar pacientes en la cola de espera
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  printf("Pacientes en espera: \n");
  ordenar_pacientes(pacientes);
  void *paciente_actual = list_first(pacientes);
  while (paciente_actual != NULL){
    paciente *paciente_ptr = (paciente *)paciente_actual;
    printf("Nombre: %s\n", paciente_ptr->nombre);
    printf("Edad: %d\n", paciente_ptr->edad);
    printf("Enfermedad: %s\n", paciente_ptr->enfermedad);
    printf("Fecha de ingreso: %s", ctime(&paciente_ptr->fecha_ingreso));
    printf("Prioridad: %s\n", paciente_ptr->prioridad == alto ? "Alto" : paciente_ptr->prioridad == medio ? "Medio" : "Bajo");
    printf("\n");
    paciente_actual = list_next(pacientes);
  }
}

void filtrar_pacientes_por_prioridad(List *pacientes, int prioridad){
  ordenar_pacientes(pacientes);
  void *paciente_actual = list_first(pacientes);
  while (paciente_actual != NULL){
    paciente *paciente_ptr = (paciente *)paciente_actual;
    if (paciente_ptr->prioridad == prioridad){
      printf("Nombre: %s\n", paciente_ptr->nombre);
      printf("Edad: %d\n", paciente_ptr->edad);
      printf("Enfermedad: %s\n", paciente_ptr->enfermedad);
      printf("Fecha de ingreso: %s", ctime(&paciente_ptr->fecha_ingreso));
      printf("Prioridad: %s\n", paciente_ptr->prioridad == alto ? "Alto" : paciente_ptr->prioridad == medio ? "Medio" : "Bajo");
    }
    paciente_actual = list_next(pacientes);
  }
}

void atender_paciente(List *pacientes){
  if (list_isEmpty(pacientes)){
    printf("No hay pacientes en espera\n");
    return;
  }
  paciente *paciente_ptr = (paciente *)list_popFront(pacientes);
  printf("Atendiendo al paciente %s\n", paciente_ptr->nombre);
  printf("Edad: %d\n", paciente_ptr->edad);
  printf("Enfermedad: %s\n", paciente_ptr->enfermedad);
  printf("Fecha de ingreso: %s", ctime(&paciente_ptr->fecha_ingreso));
  printf("Prioridad: %s\n", paciente_ptr->prioridad == alto ? "Alto" : paciente_ptr->prioridad == medio ? "Medio" : "Bajo");
  free(paciente_ptr);
}
// Función para filtrar y mostrar pacientes por prioridad

void mostrar_pacientes_prioridad(List *pacientes){
  if (list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  ordenar_pacientes(pacientes);
  int opcion;
  printf("Pacientes por prioridad: \n");
  do {
    printf("Selecciona la prioridad de pacientes a mostrar:\n");
    printf("1. Alto\n");
    printf("2. Medio\n");
    printf("3. Bajo\n");

    printf("Ingrese el número de prioridad: ");
    if(scanf("%d", &opcion) != 1) {
      printf("Entrada inválida. Intente nuevamente.\n");
      while(getchar() != '\n');
      continue;
    }
    switch (opcion) {
      case 1:
        filtrar_pacientes_por_prioridad(pacientes, alto);
        break;
      case 2:
        filtrar_pacientes_por_prioridad(pacientes, medio);
        break;
      case 3:
        filtrar_pacientes_por_prioridad(pacientes, bajo);
        break;
      default:
        printf("Opción inválida. Intente nuevamente.\n");
        break;
    } 
  }  while (opcion < 1 || opcion > 3);

}

int main() {
  char opcion;
  List *pacientes = list_create(); // puedes usar una lista para gestionar los pacientes

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %c", &opcion); // Nota el espacio antes de %c para consumir el
                           // newline anterior

    switch (opcion) {
    case '1':
      registrar_paciente(pacientes);
      break;
    case '2':
      asignar_prioridad(pacientes);
      break;
    case '3':
      mostrar_lista_pacientes(pacientes);
      break;
    case '4':
      atender_paciente(pacientes);
      break;
    case '5':
      mostrar_pacientes_prioridad(pacientes);
      break;
    case '6':
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

  } while (opcion != '6');

  // Liberar recursos, si es necesario
  list_clean(pacientes);

  return 0;
}
